# My First Website Project

This is my first website project, created as part of my GitHub and Goodwall learning journey.

## About the project

The website introduces me, the skills I am learning, projects I have worked on, and my future goals.

## Files

- `index.html` - the main website page
- `style.css` - the design and responsive styling

## What I learned

- How a basic HTML page is structured
- How CSS is used to style a website
- How to organize website files
- How to upload files to a GitHub repository
- How to make my first GitHub commit

## Goal

I want to keep learning digital skills and use technology to create positive impact.
